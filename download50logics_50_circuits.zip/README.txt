download50logics - 50 Digital Electronics Engineering lab circuits

Download download50logics_50_circuits.zip for all 50 individual Logisim .circ projects plus the combined 50-circuit project.
Or open index.html and download a circuit individually.

The Boolean-expression topics use labeled representative functions because the supplied lab PDF contains only an index.
